array=( fl{a,g}{a,g}\{{1,7}w{1,7}DL{1,7}{n,h}6_{1,7}{n,h}3_b{1,7}{n,h}4Ry_5y5{1,7}3m\} )

for i in "${array[@]}"
do
   : 
   echo $i | ./twiddling
done
